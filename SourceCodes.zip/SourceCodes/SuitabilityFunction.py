import arcpy
from arcpy.sa import *
import os
arcpy.CheckOutExtension("Spatial")
arcpy.env.overwriteOutput = True
mxd = arcpy.mapping.MapDocument("CURRENT")# if the tool is run from a stand-alone script "CURRENT" needs to be disabled or set to the path name of the mxd document
df = arcpy.mapping.ListDataFrames(mxd,"*")[0] # if line 6 is disabled, this line needs to be disabled as well
 
# Get the input parameters for the SuitabilityFunction tool
inPath = arcpy.GetParameterAsText(0)
in_Path = inPath.split(";")
min = arcpy.GetParameterAsText(1)
bmin = arcpy.GetParameterAsText(2)
max = arcpy.GetParameterAsText(3)
amax = arcpy.GetParameterAsText(4)

arcpy.env.workspace = outPath = arcpy.GetParameterAsText(5)

if min > max:
	arcpy.AddError("Error: min is larger than max") # the tool only accepts increasing suitability, i.e., the minimum value must be smaller than the maximum value
 
arcpy.AddMessage("Starting the analyses...")

# Run the SuitabilityFunction tool
for raster in in_Path:
	rescale = RescaleByFunction(raster,TfLinear(min, max,min,bmin,max,amax),"0","1") # the rescale function
	#outName = os.path.join(outPath,  "SuitFunc"+ "_"+str(os.path.basename(raster)) + "_" + str(min + "_" + max + ".tif"))
	outName = os.path.join(outPath,  "SuitFunc"+ "_"+str(os.path.basename(raster).rstrip(os.path.splitext(raster)[1])) + "_" + str(min + "_" + max + ".tif"))
	rescale.save(outName)
	newlayer = arcpy.mapping.Layer(outName) # this line needs to be disabled when the tool is run from a stand-alone script
	arcpy.mapping.AddLayer(df, newlayer,"TOP") #  this line needs to be disabled when the tool is run from a stand-alone script
 
# Report a success message    
arcpy.AddMessage("All done!")
