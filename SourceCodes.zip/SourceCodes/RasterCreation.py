import arcpy, os
arcpy.env.overwriteOutput = True
mxd = arcpy.mapping.MapDocument("CURRENT")#if the tool is run from a stand-alone script "CURRENT" needs to be disabled or set to the path name of the mxd document
df = arcpy.mapping.ListDataFrames(mxd,"*")[0] # if line 3 is disabled, this line needs to be disabled as well

inPath = arcpy.GetParameterAsText(0)
in_Path = inPath.split(";")
clip = arcpy.GetParameterAsText(1)
cellSize = arcpy.GetParameterAsText(2)

arcpy.env.workspace = outPath = arcpy.GetParameterAsText(3)

ctr = 1

for layers in in_Path:
	outName = os.path.join(outPath, str(str(os.path.basename(layers))+ "_" + "union" + ".shp"))
	inFeatures = [layers,clip]
	newFeatures = arcpy.Union_analysis(inFeatures, outName) # Union analysis
	outName1 = os.path.join(outPath, str("clip" + str(ctr) + ".shp"))
	inFeatures2 = arcpy.Clip_analysis(newFeatures, clip, outName1) # Clip analysis
	fc = arcpy.AddField_management(inFeatures2, "rasterV", "SHORT") # the field "rasterV" is added to the vector layer in order to have a value filed for the conversion to raster format
	fields = ["FID", "rasterV"]
	with arcpy.da.UpdateCursor(fc, fields) as cursor:
     #For each row, evaluate the "FID" value (index position 
     #of 0), and update "rasterV" (index position of 1)
		for row in cursor:
			if (row[0] == 0):
				row[1] = 1
			else:
				row[1] = 0
        # Update the cursor with the updated list
			cursor.updateRow(row)
	outName2 = os.path.join(outPath, "RCrea"+"_"+str(os.path.basename(layers))[:7])
	#outName2 = os.path.join(outPath, str(str(os.path.basename(layers))[:4] + "_" + str("raster") + str(ctr)))
	arcpy.PolygonToRaster_conversion(fc, "rasterV", outName2, "CELL_CENTER", "NONE", cellSize)
	newlayer = arcpy.mapping.Layer(outName2) # this line needs to be disabled when the tool is run from a stand-alone script
	arcpy.mapping.AddLayer(df, newlayer,"TOP") # this line needs to be disabled when the tool is run from a stand-alone script
	arcpy.RefreshTOC()
	arcpy.RefreshActiveView()
	ctr += 1
  
arcpy.AddMessage("Congratulations! All done!")
