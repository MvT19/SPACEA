import arcpy, os
from arcpy.sa import *
arcpy.CheckOutExtension("Spatial")
arcpy.env.overwriteOutput = True
mxd = arcpy.mapping.MapDocument("CURRENT")# if the tool is run from a stand-alone script "CURRENT" needs to be disabled or set to the path name of the mxd document
df = arcpy.mapping.ListDataFrames(mxd,"*")[0] # if line 5 is disabled, this line needs to be disabled as well
 
# Get the input parameters for the EnvThresholds tool
inPath = arcpy.GetParameterAsText(0)
in_Path = inPath.split(";")
Threshold = arcpy.GetParameterAsText(1)
Thresholds = Threshold.split(";")
ThreshLen = len(Thresholds)
PathLen = len(in_Path)

arcpy.env.workspace = outPath = arcpy.GetParameterAsText(2)

arcpy.AddMessage("Starting the analyses...")


if PathLen == ThreshLen:
	for raster, thresh in zip(in_Path, Thresholds): # the zip function matches the input layers and thresholds in the order of appearance
		maxvalue = arcpy.GetRasterProperties_management(raster, "MAXIMUM")
		minvalue = arcpy.GetRasterProperties_management(raster, "MINIMUM")		
		remap = RemapRange([[minvalue,thresh,0],[thresh,maxvalue,1]]) # the range is defined here
		reclass = Reclassify(raster,"VALUE", remap, "DATA") # the reclassify analysis
		outName = os.path.join(outPath,  "Thresh"+ "_"+ str(os.path.basename(raster).rstrip(os.path.splitext(raster)[1])) + "_" +str(os.path.basename(thresh)) + ".tif")
		reclass.save(outName)
		newlayer = arcpy.mapping.Layer(outName) # this line needs to be disabled when the tool is run from a stand-alone script
		arcpy.mapping.AddLayer(df, newlayer,"Top") # this line needs to be disabled when the tool is run from a stand-alone script
		arcpy.RefreshTOC()
		arcpy.RefreshActiveView()
else: 	# this piece of code is executed if there is only one input and several thresholds, or several inputs and just one threshold
	for raster in in_Path:
		for thresh in Thresholds:
			maxvalue = arcpy.GetRasterProperties_management(raster, "MAXIMUM")
			minvalue = arcpy.GetRasterProperties_management(raster, "MINIMUM")				
			remap = RemapRange([[minvalue,thresh,0],[thresh,maxvalue,1]])
			reclass = Reclassify(raster,"VALUE", remap, "DATA")
			outName = os.path.join(outPath,  "Thresh"+ "_"+ str(os.path.basename(raster).rstrip(os.path.splitext(raster)[1])) + "_" +str(os.path.basename(thresh)) + ".tif")
			reclass.save(outName)
			newlayer = arcpy.mapping.Layer(outName) # this line needs to be disabled when the tool is run from a stand-alone script
			arcpy.mapping.AddLayer(df, newlayer,"TOP") # this line needs to be disabled when the tool is run from a stand-alone script
			arcpy.RefreshTOC()
			arcpy.RefreshActiveView()
			
# Report a success message    
arcpy.AddMessage("All done!")
