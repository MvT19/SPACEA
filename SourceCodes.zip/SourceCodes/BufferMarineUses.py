import arcpy, os
arcpy.env.overwriteOutput = True
mxd = arcpy.mapping.MapDocument("CURRENT")# if the tool is run from a stand-alone script "CURRENT" needs to be disabled or set to the path name of the mxd document
df = arcpy.mapping.ListDataFrames(mxd,"*")[0] # if line 3 is disabled, this line needs to be disabled as well

# Get the input parameters for the BufferMarineUses tool
inPath = arcpy.GetParameterAsText(0)
in_Path = inPath.split(";")
buffers = arcpy.GetParameterAsText(1)
buffer = buffers.split(";")
BuffLen = len(buffer)
PathLen = len(in_Path)

arcpy.env.workspace = outPath = arcpy.GetParameterAsText(2)

arcpy.AddMessage("Starting the analyses...")

if PathLen == BuffLen:
	for layers, buff in zip(in_Path, buffer): # the zip function matches the first input feature with the first buffer, the second with second, etc.
		# this creates the output file name based on the input name and the chosen buffer
		outName = os.path.join(outPath, str(os.path.basename(layers)) + "_" + str(os.path.basename(buff)) + "mBuff" + ".shp")
		arcpy.Buffer_analysis(layers, outName, buff)# the buffer analysis
		newlayer = arcpy.mapping.Layer(outName) # this line needs to be disabled when the tool is run from a stand-alone script
		arcpy.mapping.AddLayer(df, newlayer,"TOP") # this line needs to be disabled when the tool is run from a stand-alone script
else: # this piece of code is executed if there is only one input and several buffer, or several inputs and just one buffer
	for layers in in_Path: 
		for buff in buffer:
			outName = os.path.join(outPath, str(os.path.basename(layers)) + "_" + str(os.path.basename(buff)) + "mBuff" + ".shp")
			arcpy.Buffer_analysis(layers, outName, buff)
			newlayer = arcpy.mapping.Layer(outName) # this line needs to be disabled when the tool is run from a stand-alone script
			arcpy.mapping.AddLayer(df, newlayer,"TOP") # this line needs to be disabled when the tool is run from a stand-alone script
# Report a success message    
arcpy.AddMessage("Congratulations! All done!")

