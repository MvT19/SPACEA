import arcpy, os
from arcpy.sa import *

arcpy.CheckOutExtension("Spatial")
arcpy.env.overwriteOutput = True
 
# Get the input parameters for the SuitabilityAnalysis tool
inPath = arcpy.GetParameterAsText(0)
in_Path = inPath.split(";")
inPath2 = arcpy.GetParameterAsText(1)
in_Path2 = inPath2.split(";")

arcpy.env.workspace = outPath = arcpy.GetParameterAsText(2)

# combining the raster layers (marine uses & environmental data), in case both are provided
try:
	# combining the raster layers (marine uses), using the geometric mean of the raster cells
	i = 0
	for raster in in_Path:
		if i==0:
			outSUM = arcpy.Raster(raster)
			i += 1
		else:
			outSUM = (outSUM * raster) ** (1/float(len(in_Path)))
			i += 1

	outName = os.path.join(outPath, str("SuitAnaly_environment")+".tif") # output name for the combined marine uses
	outSUM.save(outName)
	arcpy.SetParameterAsText(3, outName)
	
	# combining the raster layers (environmental), using the geometric mean of the raster cells
	i = 0
	for raster2 in in_Path2:
		if i==0:
			outSUM2 = arcpy.Raster(raster2)
			i += 1
		else:
			outSUM2 = (outSUM2 * raster2) ** (1/float(len(in_Path2)))
			i += 1

	outName2 = os.path.join(outPath, str("SuitAnaly_marineUses")+".tif") # output name for the combined environmental data
	outSUM2.save(outName2)
	arcpy.SetParameterAsText(4, outName2)

	# combining the "marineUses" and "environment" with the geometric mean
	outSUM3 = (outSUM * outSUM2) ** (1/2.) 
	outName3 = os.path.join(outPath, str("SuitAnaly_suitability")+".tif")
	outSUM3.save(outName3)
	arcpy.SetParameterAsText(5, outName3)
# combining the raster layers (marine uses or environmental data), in case only one type is provided
except: 
	try:
		if inPath2 == "#":
			i = 0
			for raster in in_Path:
				if i==0:
					outSUM = arcpy.Raster(raster)
					i += 1
				else:
					outSUM = (outSUM * raster) ** (1/float(len(in_Path)))
					i += 1

			outName = os.path.join(outPath, str("SuitAnaly_environment")+".tif") # output name for the combined marine uses
			outSUM.save(outName)
			arcpy.SetParameterAsText(3, outName)
		else:
			i = 0
			for raster2 in in_Path2:
				if i==0:
					outSUM2 = arcpy.Raster(raster2)
					i += 1
				else:
					outSUM2 = (outSUM2 * raster2) ** (1/float(len(in_Path2)))
					i += 1
			outName2 = os.path.join(outPath, str("SuitAnaly_marineUses")+".tif") # output name for the combined environmental data
			outSUM2.save(outName2)
			arcpy.SetParameterAsText(3, outName2)
	except:
		arcpy.AddMessage("Congratulations! All done!") 

#Report a success message    
arcpy.AddMessage("Congratulations! All done!")