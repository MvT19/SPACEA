# Name: SuitabilityAnalysis_Example2.py
# Description: Create multiple buffers for multiple input features
# Author: Miriam von Thenen

# Import system modules
import arcpy
from arcpy import env

# Set environment settings
env.workspace = "D:/Documents/GIS/Default.gdb"

arcpy.ImportToolbox("D:/Documents/GIS/Spacea.tbx")

print "Import toolbox"

# Set local variables
inFeatures1 = "Thresh_BottomCurrents_02;SuitFunc_Salinity_1_6"
inFeatures2= "RCrea_Cables_;RCrea_HELCOM_;RCrea_wind_tu"
outFolder = "D:/Documents/GIS/Results"

# Execute SuitabilityAnalysis
arcpy.SuitabilityAnalysis_Spacea(inFeatures1, inFeatures2,outFolder)

print "Script complete"