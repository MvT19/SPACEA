# Name: SuitabilityFunction_Example2.py
# Description: Create multiple buffers for multiple input features
# Author: Miriam von Thenen

# Import system modules
import arcpy
from arcpy import env

# Set environment settings
env.workspace = "D:/Documents/GIS/Default.gdb"

arcpy.ImportToolbox("D:/Documents/GIS/Spacea.tbx")

print "Import toolbox"

# Set local variables
inFeatures = "Salinity"
minValue = 1
BminValue = 0
maxValue = 6
AmaxValue = 1
outFolder = "D:/Documents/GIS/Results"

# Execute SuitabilityFunction
arcpy.SuitabilityFunction_Spacea(inFeatures, minValue,BminValue, maxValue, AmaxValue,outFolder)

print "Script complete"