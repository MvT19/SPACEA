# Name: RasterCreation_Example2.py
# Description: Create multiple buffers for multiple input features
# Author: Miriam von Thenen

# Import system modules
import arcpy
from arcpy import env

# Set environment settings
env.workspace = "D:/Documents/GIS/Default.gdb"

arcpy.ImportToolbox("D:/Documents/GIS/Spacea.tbx")

print "Import toolbox"

# Set local variables
inFeatures = "Cables_200mBuff;wind_turbines_500mBuff;HELCOM_MPAs"
clipFeature = "D:/Documents/GIS/BalticSea.shp"
cellSize = 400
outFolder = "D:/Documents/GIS/Results"

# Execute RasterCreation
arcpy.RasterCreation_Spacea(inFeatures, clipFeature, cellSize, outFolder)

print "Script complete"